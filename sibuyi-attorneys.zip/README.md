# Sibuyi Attorneys Inc. Website

A simple multipage single-page website for Sibuyi Attorneys Inc., built with HTML, CSS, and JavaScript.
